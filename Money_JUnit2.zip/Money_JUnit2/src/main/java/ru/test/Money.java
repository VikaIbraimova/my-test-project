package ru.test;

/**
 * Created by vika on 07.02.2016.
 */
public class Money {

    private int value;
    private String type;

    public Money(int value, String type) {
        this.value = value;
        this.type = type;
    }

    public int getValue(){
        return value;
    }

    public Money addMoney(Money m){
        return new Money(value + m.getValue(), type);
    }
}
