package ru.test;

/**
 * Created by vika on 07.02.2016.
 */
public class Money {

    public int value;
    public String type;

    public Money(int value, String type) {
        this.value = value;
        this.type = type;
    }

    public int getValue(){
        return value;
    }

    public String getType() {
        return type;
    }


    public Money addMoney(Money m){
        return new Money(value + m.getValue(), m.getType());
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        //return super.equals(obj);
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass())
            return false;
        Money other = (Money) obj;
        if (value != other.value)
            return false;
        if (type != other.type)
            return false;
        return true;
    }
}
