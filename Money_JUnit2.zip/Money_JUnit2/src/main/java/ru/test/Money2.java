package ru.test;

/**
 * Created by vika on 08.02.2016.
 */
public class Money2 {
    public int value;

    public Money2(int value) {
        this.value = value;
    }

    public int getValue(){
        return value;
    }

    public int addMoney(Money2 m){
        //return new Money2(value + m.getValue());
        return m.getValue()+value;
    }
}
