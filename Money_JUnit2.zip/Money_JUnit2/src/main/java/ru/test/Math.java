package ru.test;

/**
 * Created by vika on 07.02.2016.
 */
public class Math {
    public static int add (int a1, int a2) {
        return a1+a2;
    }
}
