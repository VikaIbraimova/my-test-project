package ru.test;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by vika on 07.02.2016.
 */
public class TestMoney2 {

    @Test
    public void addMoney2Test(){

        Money2 m1 = new Money2(12);
        Money2 m2 = new Money2(14);
        Money2 expected = new Money2(26);
        int result = m1.addMoney(m2);

        //assertTrue(expected.equals(result));
        //Assert.assertEquals(26,result);
        Assert.assertEquals(expected,result);
    }
}