package ru.test;


import org.junit.Assert;
import org.junit.Test;

public class TestMath {


    @Test
    public void addTest(){
        /*Money m1 = new Money(12,"RUB");
        Money m2 = new Money(14,"RUB");
        Money expected = new Money(26,"RUB");*/

        //Money m1 = new Money(12);
        //Money m2 = new Money(14);
       // Money expected = new Money(26);

        //Money result = m1.add(m1);


        /**
         * Проверяет на раванство:
         * То что получилось в результате складывания m1 и m2
         * С тем, что мы предполагаем увидить
         */
        //Assert.assertEquals(expected,result);
        /**
         * Проверяет на неравенство
         */
        //Assert.assertNotEquals(8,result);

        //------------------------

        int res = Math.add(2,2);
        Assert.assertEquals(4,res);

}
}