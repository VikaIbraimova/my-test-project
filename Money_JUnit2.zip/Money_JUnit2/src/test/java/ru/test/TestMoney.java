package ru.test;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

/**
 * Created by vika on 07.02.2016.
 */
public class TestMoney {

    @Test
    public void addMoneyTest(){

        Money m1 = new Money(12, "USD");
        Money m2 = new Money(14, "USD");
        Money expected = new Money(26, "USD");
        Money result = m1.addMoney(m2);

        //assertTrue(expected.equals(result));
        //Assert.assertEquals(expected,result);
        Assert.assertTrue(expected.equals(result));
    }
}
